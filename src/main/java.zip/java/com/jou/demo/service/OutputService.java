package com.jou.demo.service;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface OutputService {
    void output() throws IOException;

}
